#include<stdlib.h>
#include<stdio.h>

char g[sizeof(int)];

int foo(int *a) {
  int *b;
  b = a;
  memcpy((void*)b, g, sizeof(int));
  return atoi((char*)b); 
}

int main(int argc, char **argv) {
    char *p = (char *)malloc(sizeof(int));
    scanf(%d, (int*)p);
    printf("Output, %s, %d\n", argv[0], foo((int*)p));
    free(p);
    return 0;
}
