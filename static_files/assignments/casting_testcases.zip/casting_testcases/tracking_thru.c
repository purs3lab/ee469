#include<stdlib.h>
#include<stdio.h>
#include<string.h>

int main(int argc, char **argv) {
    char *p;
    char *q;
    char *s, *t;
    char **r;
    unsigned i;
    p = (char *)malloc(sizeof(int));
    if (argc < 2) {
        q = p;
    }
    if (strlen(argv[0]) > 3) {
    	*r = p;
    } else {
       *r = q;
    }
    i = strlen(argv[2]);
    while(i) {
    	*(int *)(*r) = atoi(argv[1] + i);
    	*r = t;
    	i--;
    }    
    *r = s;    
    return 0;
}
